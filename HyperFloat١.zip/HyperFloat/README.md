# Hyper Float V1.1

HyperOS-inspired floating windows for Android 11+ (target: Android 15, 4 GB RAM).
Kotlin + framework Views + WindowManager. No third-party libraries.

STATUS: this ZIP has NOT been compiled by its author (no SDK/network in the authoring sandbox).
The first real build is the verification. Report any compiler error and it will be fixed.

## Toolchain (pinned)
| Piece | Version | Note |
|---|---|---|
| Android Gradle Plugin | 8.7.3 | needs Gradle >= 8.9, JDK 17, supports compileSdk 35 |
| Gradle | 8.9 | wrapper properties pinned |
| Kotlin | 2.0.21 | same combo as Android Studio Ladybug's project template |
| JDK | 17 | jvmTarget 17 |
| compileSdk / targetSdk / minSdk | 35 / 35 / 30 | |

## The wrapper jar
`gradle/wrapper/gradle-wrapper.jar` is a binary and is NOT in this ZIP (it could not be downloaded or
honestly recreated offline). `./gradlew` downloads it once from github.com/gradle/gradle (tag v8.9.0)
if it is missing. The GitHub workflow instead generates it with `gradle wrapper` and uploads
`gradle-wrapper-files` as an artifact you can commit.

## Build
- GitHub Actions: put the project in a repo, keep `.github/workflows/build.yml` at the REPO ROOT,
  run "Build debug APK", download artifact `HyperFloat-debug-apk`.
- Terminal (Termux/PC with JDK 17 + Android SDK 35): `sh gradlew assembleDebug`
- AndroidIDE: open the folder, Run. If SDK 35 is missing, set compileSdk/targetSdk to 34.

## REAL vs SIMULATED
Real: overlay windows (move/resize/maximize/close), minimize to bubbles, restore, up to 5 windows,
edge sidebar, foreground service, Notes / Calculator / Stopwatch / Browser(WebView), app launcher grid.
Simulated: windows for installed apps are shortcut cards. Android cannot embed other apps' UI in an overlay.
"Open in half-screen" only works on devices with freeform windowing enabled.
