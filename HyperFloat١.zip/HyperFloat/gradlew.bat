@echo off
rem Hyper Float Gradle wrapper launcher (Windows). Needs gradle\wrapper\gradle-wrapper.jar (see README).
set APP_HOME=%~dp0
set JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not exist "%JAR%" (
  echo ERROR: gradle\wrapper\gradle-wrapper.jar is missing. See README.
  exit /b 1
)
if defined JAVA_HOME (set JAVACMD=%JAVA_HOME%\bin\java.exe) else (set JAVACMD=java.exe)
"%JAVACMD%" -Xmx64m -Xms64m -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
