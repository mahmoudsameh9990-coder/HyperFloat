# V1.1 changes
See the chat reply for the full list. Files touched: OverlayService.kt, FloatingWindow.kt,
build.gradle.kts (version 1.1.0), gradlew, gradlew.bat, gradle-wrapper.properties, build.yml, README.md.
