package com.hyperfloat.app

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** What lives inside a floating window. Always Hyper Float's own view tree. */
class Content(
    val view: View,
    val needsInput: Boolean = false,
    val onTrim: () -> Unit = {},
    val onDestroy: () -> Unit = {}
)

/**
 * One movable / resizable overlay window built on WindowManager.
 * The window's view is kept alive while minimized (detached) so state survives.
 */
class FloatingWindow(
    val id: Int,
    val key: String,
    val title: String,
    val icon: Drawable?,
    private val ctx: Context,
    private val wm: WindowManager,
    val content: Content,
    private val host: Host,
    startIndex: Int
) {
    interface Host {
        fun onMinimize(w: FloatingWindow)
        fun onClose(w: FloatingWindow)
        fun onRaise(w: FloatingWindow)
    }

    private class InputFrame(c: Context) : FrameLayout(c) {
        var onDown: (() -> Unit)? = null
        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) onDown?.invoke()
            return false
        }
    }

    val root = FrameLayout(ctx)
    val params: LP
    var attached = false
        private set
    var maximized = false
        private set

    private val saved = IntArray(4)
    private val minW = ctx.dp(200)
    private val minH = ctx.dp(160)
    private val focusListener =
        ViewTreeObserver.OnWindowFocusChangeListener { has -> if (!has) setFocusable(false) }

    init {
        val self = this
        val u = usableBounds(wm, ctx)
        val w = minOf(ctx.dp(320), (u.width() * 0.92f).toInt())
        val h = minOf(ctx.dp(440), (u.height() * 0.62f).toInt())
        val step = ctx.dp(26) * (startIndex % 6)
        params = LP(
            w, h, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (u.left + ctx.dp(12) + step).coerceAtMost(u.right - w)
            y = (u.top + ctx.dp(24) + step).coerceAtMost(u.bottom - h)
            softInputMode = LP.SOFT_INPUT_ADJUST_PAN
        }

        // ---- title bar ----
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Hx.CARD)
            setPadding(ctx.dp(12), 0, ctx.dp(6), 0)
        }
        if (icon != null) {
            bar.addView(ImageView(ctx).apply { setImageDrawable(icon) },
                LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22)).apply { marginEnd = ctx.dp(8) })
        }
        bar.addView(ctx.txt(title, 15f, Hx.TEXT, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        fun ctrl(label: String, bg: Int, fg: Int, click: () -> Unit) = ctx.txt(label, 15f, fg, true).apply {
            gravity = Gravity.CENTER
            background = round(bg, ctx.dp(17).toFloat())
            setOnClickListener { click() }
        }
        fun addCtrl(v: View) = bar.addView(v, LinearLayout.LayoutParams(ctx.dp(34), ctx.dp(34)).apply {
            marginStart = ctx.dp(6)
        })
        addCtrl(ctrl("—", Hx.SOFT, Hx.TEXT) { host.onMinimize(self) })
        addCtrl(ctrl("▢", Hx.SOFT, Hx.TEXT) { toggleMaximize() })
        addCtrl(ctrl("✕", Hx.DANGER, 0xFFFFFFFF.toInt()) { host.onClose(self) })

        bar.setOnTouchListener(object : View.OnTouchListener {
            var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dx = e.rawX; dy = e.rawY; sx = params.x; sy = params.y; moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val mx = e.rawX - dx; val my = e.rawY - dy
                        if (!moved && (abs(mx) > ctx.dp(6) || abs(my) > ctx.dp(6))) moved = true
                        if (moved && !maximized) {
                            params.x = sx + mx.toInt(); params.y = sy + my.toInt()
                            clamp(); update()
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) host.onRaise(self)
                }
                return true
            }
        })

        // ---- content ----
        val frame = InputFrame(ctx).apply {
            setBackgroundColor(Hx.CARD)
            onDown = { if (content.needsInput) setFocusable(true) }
            addView(content.view, FrameLayout.LayoutParams(-1, -1))
        }
        val divider = View(ctx).apply { setBackgroundColor(Hx.SOFT) }
        val column = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        column.addView(bar, LinearLayout.LayoutParams(-1, ctx.dp(44)))
        column.addView(divider, LinearLayout.LayoutParams(-1, 1))
        column.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        // ---- resize handle (bottom-right) ----
        val handle = TextView(ctx).apply {
            text = "◢"; textSize = 14f; setTextColor(Hx.SUB); gravity = Gravity.CENTER
        }
        handle.setOnTouchListener(object : View.OnTouchListener {
            var rx = 0f; var ry = 0f; var sw = 0; var sh = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { rx = e.rawX; ry = e.rawY; sw = params.width; sh = params.height }
                    MotionEvent.ACTION_MOVE -> if (!maximized) {
                        params.width = sw + (e.rawX - rx).toInt()
                        params.height = sh + (e.rawY - ry).toInt()
                        clamp(); update()
                    }
                }
                return true
            }
        })

        root.background = round(Hx.CARD, ctx.dp(22).toFloat(), Hx.SOFT, ctx.dp(1))
        root.clipToOutline = true
        root.outlineProvider = ViewOutlineProvider.BACKGROUND
        root.addView(column, FrameLayout.LayoutParams(-1, -1))
        root.addView(handle, FrameLayout.LayoutParams(ctx.dp(36), ctx.dp(36), Gravity.BOTTOM or Gravity.END))
    }

    private fun clamp() {
        val u = usableBounds(wm, ctx)
        params.width = params.width.coerceIn(minW, maxOf(minW, u.width()))
        params.height = params.height.coerceIn(minH, maxOf(minH, u.height()))
        params.x = params.x.coerceIn(u.left, maxOf(u.left, u.right - params.width))
        params.y = params.y.coerceIn(u.top, maxOf(u.top, u.bottom - params.height))
    }

    private fun update() {
        if (!attached) return
        try { wm.updateViewLayout(root, params) } catch (_: IllegalArgumentException) {}
    }

    /** Re-fit after rotation / display change. */
    fun relayout() {
        if (maximized) {
            val u = usableBounds(wm, ctx)
            params.x = u.left; params.y = u.top; params.width = u.width(); params.height = u.height()
        } else clamp()
        update()
    }

    fun toggleMaximize() {
        if (!maximized) {
            saved[0] = params.x; saved[1] = params.y; saved[2] = params.width; saved[3] = params.height
            val u = usableBounds(wm, ctx)
            params.x = u.left; params.y = u.top; params.width = u.width(); params.height = u.height()
            maximized = true
        } else {
            params.x = saved[0]; params.y = saved[1]; params.width = saved[2]; params.height = saved[3]
            maximized = false
            clamp()
        }
        update()
    }

    /** Only focusable while the user is typing; otherwise touches/keys pass through to apps below. */
    fun setFocusable(on: Boolean) {
        if (!attached) return
        val isFocusable = (params.flags and LP.FLAG_NOT_FOCUSABLE) == 0
        if (isFocusable == on) return
        params.flags = if (on) params.flags and LP.FLAG_NOT_FOCUSABLE.inv()
        else params.flags or LP.FLAG_NOT_FOCUSABLE
        update()
    }

    fun attach(): Boolean {
        if (attached) return true
        return try {
            clamp()
            params.flags = params.flags or LP.FLAG_NOT_FOCUSABLE
            wm.addView(root, params)
            attached = true
            root.viewTreeObserver.addOnWindowFocusChangeListener(focusListener)
            true
        } catch (e: Exception) { // BadTokenException / SecurityException if permission revoked
            false
        }
    }

    fun detach() {
        if (!attached) return
        try { wm.removeViewImmediate(root) } catch (_: Exception) {}
        attached = false
    }

    fun destroy() {
        detach()
        try { content.onDestroy() } catch (_: Exception) {}
    }
}
