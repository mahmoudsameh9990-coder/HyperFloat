@file:Suppress("DEPRECATION")

package com.hyperfloat.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private class AppEntry(val label: String, val pkg: String)
    private class Holder(val icon: ImageView, val label: TextView)

    private val all = ArrayList<AppEntry>()
    private val shown = ArrayList<AppEntry>()
    private val icons = LruCache<String, Drawable>(48) // small cache = low RAM
    private val io = Executors.newSingleThreadExecutor()
    private val reqNotif = 7

    private lateinit var status: TextView
    private lateinit var mainBtn: TextView
    private lateinit var tools: LinearLayout
    private lateinit var adapter: BaseAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        refreshState()
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi() {
        val outer = LinearLayout(this).apply { setBackgroundColor(Hx.BG) }
        // Android 15 forces edge-to-edge: pad for system bars ourselves.
        outer.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsets.CONSUMED
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        outer.addView(col, LinearLayout.LayoutParams(-1, -1))

        col.addView(txt("Hyper Float", 30f, Hx.TEXT, true))
        col.addView(txt("Floating windows for your phone", 14f, Hx.SUB))

        // status card
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(Hx.CARD, dp(22).toFloat())
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        status = txt("", 13f, Hx.SUB)
        mainBtn = pill("", Hx.ACCENT, Color.WHITE, 15f) { onMainButton() }
        card.addView(status)
        card.addView(mainBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // tools row
        tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun tool(label: String, t: String) = tools.addView(
            pill(label, Hx.CARD, Hx.TEXT, 12f) { sendTool(t) },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        tool("📝 Notes", "notes"); tool("🧮 Calc", "calc"); tool("🌐 Web", "web"); tool("⏱ Timer", "stopwatch")
        col.addView(tools, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        col.addView(txt(
            "Real: Notes, Calculator, Browser and Stopwatch run inside the windows. " +
                "Simulated: apps below open as shortcut cards – Android cannot embed other apps in overlays.",
            11f, Hx.SUB), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        // search
        val search = EditText(this).apply {
            hint = "Search apps"; setSingleLine(); textSize = 14f; setTextColor(Hx.TEXT)
            background = round(Hx.CARD, dp(16).toFloat())
            setPadding(dp(14), dp(10), dp(14), dp(10))
            ellipsize = TextUtils.TruncateAt.END
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = filter(s?.toString() ?: "")
        })
        col.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // app grid
        adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(position: Int) = shown[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view: View; val h: Holder
                if (convertView == null) {
                    val iv = ImageView(this@MainActivity)
                    val tv = txt("", 11f, Hx.TEXT).apply {
                        gravity = Gravity.CENTER; maxLines = 2; ellipsize = TextUtils.TruncateAt.END
                    }
                    val box = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                        setPadding(dp(2), dp(8), dp(2), dp(8))
                        addView(iv, LinearLayout.LayoutParams(dp(48), dp(48)))
                        addView(tv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
                    }
                    h = Holder(iv, tv); box.tag = h; view = box
                } else { view = convertView; h = convertView.tag as Holder }
                val e = shown[position]
                h.label.text = e.label
                h.icon.setImageDrawable(iconFor(e.pkg))
                return view
            }
        }
        val grid = GridView(this).apply {
            numColumns = 4
            adapter = this@MainActivity.adapter
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            setOnItemClickListener { _, _, pos, _ -> sendApp(shown[pos].pkg) }
        }
        col.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })
        setContentView(outer)
    }

    private fun iconFor(pkg: String): Drawable? =
        icons.get(pkg) ?: try {
            packageManager.getApplicationIcon(pkg).also { icons.put(pkg, it) }
        } catch (e: Exception) { null }

    private fun loadApps() {
        io.execute {
            try {
                val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val list = if (Build.VERSION.SDK_INT >= 33)
                    packageManager.queryIntentActivities(q, PackageManager.ResolveInfoFlags.of(0))
                else packageManager.queryIntentActivities(q, 0)
                val apps = list
                    .map { AppEntry(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
                    .filter { it.pkg != packageName }
                    .distinctBy { it.pkg }
                    .sortedBy { it.label.lowercase() }
                runOnUiThread {
                    all.clear(); all.addAll(apps)
                    filter("")
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Could not list apps: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun filter(q: String) {
        shown.clear()
        shown.addAll(if (q.isBlank()) all else all.filter { it.label.contains(q, ignoreCase = true) })
        adapter.notifyDataSetChanged()
    }

    // ------------------------------------------------------------------ state / actions

    private fun refreshState() {
        val granted = Settings.canDrawOverlays(this)
        val running = OverlayService.running
        status.text = "Overlay permission: ${if (granted) "granted ✓" else "required"}\n" +
            "Service: ${if (running) "running ✓" else "stopped"}"
        mainBtn.text = when {
            !granted -> "Grant overlay permission"
            running -> "Stop Hyper Float"
            else -> "Start Hyper Float"
        }
        tools.alpha = if (granted) 1f else 0.4f
    }

    private fun onMainButton() {
        when {
            !Settings.canDrawOverlays(this) -> requestOverlayPermission()
            OverlayService.running -> {
                stopService(Intent(this, OverlayService::class.java))
                window.decorView.postDelayed({ refreshState() }, 400)
            }
            Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED ->
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            else -> startFloat()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // The service works even if the notification is hidden, so start either way.
        if (requestCode == reqNotif) startFloat()
    }

    private fun startFloat() {
        try {
            OverlayService.send(this, OverlayService.ACTION_START)
            window.decorView.postDelayed({ refreshState() }, 500)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start service: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestOverlayPermission() {
        Toast.makeText(this, "Find Hyper Float and turn on “Allow display over other apps”", Toast.LENGTH_LONG).show()
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
        }
    }

    private fun ensureReady(): Boolean {
        if (!Settings.canDrawOverlays(this)) { requestOverlayPermission(); return false }
        return true
    }

    private fun sendTool(tool: String) {
        if (!ensureReady()) return
        try { OverlayService.send(this, OverlayService.ACTION_TOOL, tool = tool) } catch (e: Exception) {
            Toast.makeText(this, "Could not start: ${e.message}", Toast.LENGTH_LONG).show()
        }
        window.decorView.postDelayed({ refreshState() }, 500)
    }

    private fun sendApp(pkg: String) {
        if (!ensureReady()) return
        try { OverlayService.send(this, OverlayService.ACTION_APP, pkg = pkg) } catch (e: Exception) {
            Toast.makeText(this, "Could not start: ${e.message}", Toast.LENGTH_LONG).show()
        }
        window.decorView.postDelayed({ refreshState() }, 500)
    }
}
