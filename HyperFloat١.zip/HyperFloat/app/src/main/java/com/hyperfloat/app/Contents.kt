@file:Suppress("DEPRECATION")

package com.hyperfloat.app

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Window contents. Everything here is REAL functionality running inside Hyper Float's own process. */
object Contents {

    fun notes(ctx: Context): Content {
        val prefs = ctx.getSharedPreferences("notes", Context.MODE_PRIVATE)
        val et = EditText(ctx).apply {
            setText(prefs.getString("text", ""))
            hint = "Write a note… (saved automatically)"
            gravity = Gravity.TOP or Gravity.START
            setBackgroundColor(Color.TRANSPARENT)
            setTextColor(Hx.TEXT)
            textSize = 15f
            setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(40))
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                prefs.edit().putString("text", s?.toString() ?: "").apply()
            }
        })
        return Content(et, needsInput = true)
    }

    fun calculator(ctx: Context): Content {
        var cur = "0"; var acc: Double? = null; var op: Char? = null; var fresh = true
        val display = TextView(ctx).apply {
            textSize = 32f; setTextColor(Hx.TEXT); maxLines = 1; text = "0"
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(16), ctx.dp(8), ctx.dp(16), ctx.dp(8))
        }
        fun fmt(d: Double): String = when {
            d.isNaN() || d.isInfinite() -> "Error"
            d == Math.floor(d) && Math.abs(d) < 1e15 -> d.toLong().toString()
            else -> d.toString().take(12)
        }
        fun compute() {
            val a = acc; val o = op
            if (a != null && o != null && !fresh) {
                val b = cur.toDoubleOrNull() ?: 0.0
                val r = when (o) {
                    '+' -> a + b; '−' -> a - b; '×' -> a * b
                    else -> if (b == 0.0) Double.NaN else a / b
                }
                cur = fmt(r)
            }
        }
        fun press(k: String) {
            when {
                k == "C" -> { cur = "0"; acc = null; op = null; fresh = true }
                k.length == 1 && k[0].isDigit() -> {
                    cur = if (fresh || cur == "0" || cur == "Error") k else cur + k; fresh = false
                }
                k == "." -> {
                    if (fresh || cur == "Error") { cur = "0."; fresh = false }
                    else if (!cur.contains('.')) cur += "."
                }
                k == "±" -> if (cur != "0" && cur != "Error") cur = if (cur.startsWith("-")) cur.drop(1) else "-$cur"
                k == "%" -> cur = fmt((cur.toDoubleOrNull() ?: 0.0) / 100)
                k == "=" -> { compute(); acc = null; op = null; fresh = true }
                else -> { compute(); acc = cur.toDoubleOrNull(); op = k[0]; fresh = true }
            }
            display.text = cur
        }
        val rows = listOf(
            listOf("C", "±", "%", "÷"), listOf("7", "8", "9", "×"), listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"), listOf("0", ".", "=")
        )
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(display, LinearLayout.LayoutParams(-1, ctx.dp(70)))
        for (r in rows) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in r) {
                val isOp = k in listOf("÷", "×", "−", "+", "=")
                val key = ctx.txt(k, 20f, if (isOp) 0xFFFFFFFF.toInt() else Hx.TEXT, true).apply {
                    gravity = Gravity.CENTER
                    background = round(if (isOp) Hx.ACCENT else Hx.SOFT, ctx.dp(14).toFloat())
                    setOnClickListener { press(k) }
                }
                row.addView(key, LinearLayout.LayoutParams(0, -1, if (k == "0") 2f else 1f).apply {
                    setMargins(ctx.dp(3), ctx.dp(3), ctx.dp(3), ctx.dp(3))
                })
            }
            col.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        col.setPadding(ctx.dp(6), 0, ctx.dp(6), ctx.dp(6))
        return Content(col)
    }

    fun stopwatch(ctx: Context): Content {
        val h = Handler(Looper.getMainLooper())
        var running = false; var base = 0L; var acc = 0L
        val tv = TextView(ctx).apply {
            textSize = 40f; setTextColor(Hx.TEXT); gravity = Gravity.CENTER; text = "00:00.0"
        }
        fun fmt(ms: Long): String {
            val t = ms / 100; val s = t / 10 % 60; val m = t / 600
            return "%02d:%02d.%d".format(m, s, t % 10)
        }
        val tick = object : Runnable {
            override fun run() {
                tv.text = fmt(acc + SystemClock.elapsedRealtime() - base)
                h.postDelayed(this, 200)
            }
        }
        lateinit var startBtn: TextView
        startBtn = ctx.pill("Start", Hx.ACCENT, 0xFFFFFFFF.toInt()) {
            if (running) {
                acc += SystemClock.elapsedRealtime() - base; running = false
                h.removeCallbacks(tick); startBtn.text = "Start"
            } else {
                base = SystemClock.elapsedRealtime(); running = true
                h.post(tick); startBtn.text = "Pause"
            }
        }
        val reset = ctx.pill("Reset") {
            running = false; acc = 0; h.removeCallbacks(tick); tv.text = "00:00.0"; startBtn.text = "Start"
        }
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(ctx.dp(16), 0, ctx.dp(16), 0) }
        col.addView(tv, LinearLayout.LayoutParams(-1, -2))
        val btns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        btns.addView(startBtn, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = ctx.dp(6) })
        btns.addView(reset, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ctx.dp(6) })
        col.addView(btns, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dp(16) })
        return Content(col, onDestroy = { h.removeCallbacks(tick) })
    }

    /** A real WebView running inside the overlay (it is OUR content, so Android allows it). */
    fun browser(ctx: Context): Content {
        val url = EditText(ctx).apply {
            setSingleLine(); hint = "Search or enter address"; textSize = 14f
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setTextColor(Hx.TEXT)
            background = round(Hx.SOFT, ctx.dp(12).toFloat())
            setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(8))
            ellipsize = TextUtils.TruncateAt.END
        }
        val wv = WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, u: String?, favicon: Bitmap?) {
                    if (!url.hasFocus() && u != null) url.setText(u)
                }
            }
        }
        fun go(input: String) {
            val s = input.trim()
            if (s.isEmpty()) return
            val target = when {
                s.contains("://") -> s
                s.contains('.') && !s.contains(' ') -> "https://$s"
                else -> "https://duckduckgo.com/?q=" + Uri.encode(s)
            }
            wv.loadUrl(target)
        }
        url.setOnEditorActionListener { v, _, _ -> go(v.text.toString()); v.clearFocus(); true }
        val back = ctx.pill("‹", sp = 18f) { if (wv.canGoBack()) wv.goBack() }
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(8), ctx.dp(6), ctx.dp(8), ctx.dp(6))
        }
        bar.addView(back, LinearLayout.LayoutParams(ctx.dp(44), -2).apply { marginEnd = ctx.dp(6) })
        bar.addView(url, LinearLayout.LayoutParams(0, -2, 1f))
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(bar, LinearLayout.LayoutParams(-1, -2))
        col.addView(wv, LinearLayout.LayoutParams(-1, 0, 1f))
        wv.loadUrl("https://duckduckgo.com")
        return Content(col, needsInput = true,
            onTrim = { wv.clearCache(true) },
            onDestroy = {
                wv.stopLoading()
                (wv.parent as? ViewGroup)?.removeView(wv)
                wv.destroy()
            })
    }

    /**
     * SIMULATED window for an installed app: a Hyper Float shortcut card.
     * Android does NOT let one app render another app's UI inside its overlay.
     */
    fun appCard(ctx: Context, pkg: String, label: String, icon: Drawable?): Content {
        val version = try { ctx.packageManager.getPackageInfo(pkg, 0).versionName ?: "?" } catch (e: Exception) { "?" }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ctx.dp(16), ctx.dp(16), ctx.dp(16), ctx.dp(16))
        }
        col.addView(ImageView(ctx).apply { setImageDrawable(icon) }, LinearLayout.LayoutParams(ctx.dp(64), ctx.dp(64)))
        col.addView(ctx.txt(label, 18f, Hx.TEXT, true).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dp(8) })
        col.addView(ctx.txt(pkg, 11f, Hx.SUB).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2))
        col.addView(ctx.txt("Version $version", 12f, Hx.SUB).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2))
        fun add(v: android.view.View) = col.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dp(10) })
        add(ctx.pill("Open app", Hx.ACCENT, 0xFFFFFFFF.toInt()) { launch(ctx, pkg, null) })
        add(ctx.pill("Open in half-screen (experimental)") {
            val wm = ctx.getSystemService(WindowManager::class.java)
            val u = usableBounds(wm, ctx)
            launch(ctx, pkg, Rect(u.left, u.top, u.right, u.top + u.height() / 2))
        })
        add(ctx.pill("App info") {
            try {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { toast(ctx, "Could not open app info") }
        })
        add(ctx.txt("This is a Hyper Float shortcut card. Android does not allow other apps' screens to be embedded in overlay windows, so “Open app” launches the real app normally.", 11f, Hx.SUB))
        return Content(ScrollView(ctx).apply { addView(col) })
    }

    private fun launch(ctx: Context, pkg: String, bounds: Rect?) {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) { toast(ctx, "This app has no launch screen"); return }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (bounds != null) {
                // Only honoured on devices with freeform windowing enabled; otherwise opens normally.
                ctx.startActivity(intent, ActivityOptions.makeBasic().setLaunchBounds(bounds).toBundle())
            } else ctx.startActivity(intent)
        } catch (e: Exception) {
            toast(ctx, "Android blocked the launch (${e.javaClass.simpleName})")
        }
    }

    private fun toast(ctx: Context, m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
}
