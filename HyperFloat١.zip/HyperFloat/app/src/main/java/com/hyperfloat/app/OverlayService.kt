@file:Suppress("DEPRECATION")

package com.hyperfloat.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

/**
 * Owns every overlay: floating windows, minimized bubbles and the edge sidebar.
 * Runs as a foreground service (type specialUse) so Android keeps it alive.
 */
class OverlayService : Service(), FloatingWindow.Host {

    companion object {
        const val ACTION_START = "com.hyperfloat.START"
        const val ACTION_STOP = "com.hyperfloat.STOP"
        const val ACTION_TOOL = "com.hyperfloat.TOOL"
        const val ACTION_APP = "com.hyperfloat.APP"
        const val EXTRA_TOOL = "tool"
        const val EXTRA_PKG = "pkg"
        const val MAX_WINDOWS = 5 // memory guard for 4 GB devices
        private const val CHANNEL = "hyperfloat_overlay"
        private const val NOTIF_ID = 1

        @Volatile var running = false
            private set

        fun send(ctx: Context, action: String, tool: String? = null, pkg: String? = null) {
            val i = Intent(ctx, OverlayService::class.java).setAction(action)
            tool?.let { i.putExtra(EXTRA_TOOL, it) }
            pkg?.let { i.putExtra(EXTRA_PKG, it) }
            ctx.startForegroundService(i)
        }
    }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val windows = LinkedHashMap<Int, FloatingWindow>()
    private val bubbles = HashMap<Int, Pair<View, LP>>()
    private var nextId = 1
    private var topId = -1

    private var sidebar: View? = null
    private var sbParams: LP? = null
    private var sbPanel: LinearLayout? = null

    private fun overlayFlags() = LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL or LP.FLAG_LAYOUT_IN_SCREEN

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        // A window context (API 31+) is the correct owner of overlay windows: its metrics follow the display.
        wm = try {
            if (Build.VERSION.SDK_INT >= 31)
                createWindowContext(LP.TYPE_APPLICATION_OVERLAY, null).getSystemService(WindowManager::class.java)
            else getSystemService(WindowManager::class.java)
        } catch (e: Exception) {
            getSystemService(WindowManager::class.java)
        }
        val ch = NotificationChannel(CHANNEL, "Hyper Float", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Must be called promptly after startForegroundService(), even if we stop right after.
        if (!startAsForeground()) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (!Settings.canDrawOverlays(this)) {
            toast("Overlay permission is missing – open Hyper Float and grant it.")
            stopSelf(); return START_NOT_STICKY
        }
        ensureSidebar()
        when (intent?.action) {
            ACTION_TOOL -> intent?.getStringExtra(EXTRA_TOOL)?.let { openTool(it) }
            ACTION_APP -> intent?.getStringExtra(EXTRA_PKG)?.let { openAppCard(it) }
        }
        return START_STICKY // if killed, Android restarts us with a null intent -> sidebar is rebuilt
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ui.post { relayoutAll() }
    }

    /** After rotation / fold / display-size change: pull everything back on screen. */
    private fun relayoutAll() {
        windows.values.forEach { it.relayout() }
        val u = usableBounds(wm, this)
        val size = dp(54)
        for ((v, p) in bubbles.values) {
            p.x = if (p.x + size / 2 < (u.left + u.right) / 2) u.left else u.right - size
            p.y = p.y.coerceIn(u.top, maxOf(u.top, u.bottom - size))
            try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
        }
        val sv = sidebar; val sp = sbParams
        if (sv != null && sp != null) {
            sp.y = sp.y.coerceIn(u.top, maxOf(u.top, u.bottom - dp(100)))
            try { wm.updateViewLayout(sv, sp) } catch (_: Exception) {}
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW) windows.values.forEach { it.content.onTrim() }
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        bubbles.values.forEach { try { wm.removeViewImmediate(it.first) } catch (_: Exception) {} }
        bubbles.clear()
        windows.values.toList().forEach { it.destroy() }
        windows.clear()
        sidebar?.let { try { wm.removeViewImmediate(it) } catch (_: Exception) {} }
        sidebar = null
        super.onDestroy()
    }

    /** Returns false if Android refuses (e.g. a sticky restart from the background on Android 12+). */
    private fun startAsForeground(): Boolean {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Hyper Float is active")
            .setContentText("Use the edge handle for tools and windows")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notif), "Stop", stop).build())
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(NOTIF_ID, n)
            true
        } catch (e: Exception) { // ForegroundServiceStartNotAllowedException / SecurityException
            false
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- windows

    private fun openTool(tool: String) {
        when (tool) {
            "notes" -> openWindow("tool:notes", "Notes", null) { Contents.notes(this) }
            "calc" -> openWindow("tool:calc", "Calculator", null) { Contents.calculator(this) }
            "web" -> openWindow("tool:web", "Browser", null) { Contents.browser(this) }
            "stopwatch" -> openWindow("tool:stopwatch", "Stopwatch", null) { Contents.stopwatch(this) }
        }
    }

    private fun openAppCard(pkg: String) {
        val pm = packageManager
        val label = try { pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString() } catch (e: Exception) { toast("App not found"); return }
        val icon = try { pm.getApplicationIcon(pkg) } catch (e: Exception) { null }
        openWindow("app:$pkg", label, icon) { Contents.appCard(this, pkg, label, icon) }
    }

    private fun openWindow(key: String, title: String, icon: Drawable?, factory: () -> Content) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Overlay permission was revoked – grant it again in Hyper Float.")
            stopSelf(); return
        }
        windows.values.firstOrNull { it.key == key }?.let { raise(it); return }
        if (windows.size >= MAX_WINDOWS) {
            toast("Limit of $MAX_WINDOWS windows reached (protects memory). Close one first.")
            return
        }
        val content = try { factory() } catch (e: Exception) { toast("Could not create window: ${e.message}"); return }
        val w = FloatingWindow(nextId++, key, title, icon, this, wm, content, this, windows.size)
        if (!w.attach()) {
            content.onDestroy()
            toast("Android refused the overlay (is the permission still granted?)")
            return
        }
        windows[w.id] = w
        topId = w.id
        bumpSidebar()
        refreshPanelIfOpen()
    }

    private fun raise(w: FloatingWindow) {
        if (bubbles.containsKey(w.id)) { restore(w); return }
        if (topId != w.id) { w.detach(); w.attach(); topId = w.id; bumpSidebar() }
    }

    // Host callbacks come from inside a window's own touch/click dispatch. Adding/removing that window
    // right there is unsafe, so all structural changes are posted to the next main-loop turn.
    override fun onRaise(w: FloatingWindow) { ui.post { if (windows.containsKey(w.id)) raise(w) } }
    override fun onMinimize(w: FloatingWindow) { ui.post { if (windows.containsKey(w.id)) minimize(w) } }
    override fun onClose(w: FloatingWindow) { ui.post { closeWindow(w) } }

    private fun minimize(w: FloatingWindow) {
        w.detach()
        if (topId == w.id) topId = -1
        showBubble(w)
        refreshPanelIfOpen()
    }

    private fun restore(w: FloatingWindow) {
        removeBubble(w.id)
        if (!w.attach()) { toast("Could not restore window"); return }
        topId = w.id
        bumpSidebar()
        refreshPanelIfOpen()
    }

    private fun closeWindow(w: FloatingWindow) {
        if (windows.remove(w.id) == null) return // already closed
        removeBubble(w.id)
        w.destroy()
        if (topId == w.id) topId = -1
        refreshPanelIfOpen()
    }

    // ---------------------------------------------------------------- bubbles

    private fun removeBubble(id: Int) {
        bubbles.remove(id)?.let { (v, _) -> try { wm.removeViewImmediate(v) } catch (_: Exception) {} }
    }

    private fun showBubble(w: FloatingWindow) {
        val size = dp(54)
        val u = usableBounds(wm, this)
        val bubble: View = if (w.icon != null) {
            ImageView(this).apply { setImageDrawable(w.icon); setPadding(dp(10), dp(10), dp(10), dp(10)) }
        } else {
            TextView(this).apply {
                text = w.title.take(1).uppercase(); gravity = Gravity.CENTER
                textSize = 20f; setTextColor(Hx.ACCENT); setTypeface(typeface, android.graphics.Typeface.BOLD)
            }
        }
        bubble.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(Hx.CARD); setStroke(dp(2), Hx.ACCENT)
        }
        val p = LP(size, size, LP.TYPE_APPLICATION_OVERLAY, overlayFlags(), PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = u.right - size
            y = (u.top + dp(80) + bubbles.size * dp(62)).coerceAtMost(u.bottom - size)
        }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var moved = false; var longFired = false
        val longPress = Runnable {
            longFired = true
            bubble.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            onClose(w) // long-press a bubble = close that window
        }
        bubble.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y
                    moved = false; longFired = false
                    ui.postDelayed(longPress, 700)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (!moved && hypot(dx, dy) > dp(8)) { moved = true; ui.removeCallbacks(longPress) }
                    if (moved) {
                        p.x = (startX + dx).toInt(); p.y = (startY + dy).toInt()
                        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(longPress)
                    if (!longFired) {
                        if (moved) { // snap to nearest horizontal edge
                            val b = usableBounds(wm, this)
                            p.x = if (p.x + size / 2 < (b.left + b.right) / 2) b.left else b.right - size
                            p.y = p.y.coerceIn(b.top, b.bottom - size)
                            try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
                        } else if (e.actionMasked == MotionEvent.ACTION_UP) ui.post { if (bubbles.containsKey(w.id)) restore(w) }
                    }
                }
            }
            true
        }
        try {
            wm.addView(bubble, p)
            bubbles[w.id] = Pair(bubble, p)
        } catch (e: Exception) {
            toast("Could not create bubble; restoring window")
            if (w.attach()) topId = w.id
        }
    }

    // ---------------------------------------------------------------- sidebar

    private fun ensureSidebar() {
        if (sidebar != null) return
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            background = round(Hx.CARD, dp(18).toFloat(), Hx.SOFT, dp(1))
            setPadding(dp(10), dp(10), dp(10), dp(10))
            minimumWidth = dp(180)
        }
        val handle = View(this).apply { background = round(Hx.ACCENT, dp(5).toFloat()); alpha = 0.85f }
        val rootView = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(panel, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
            addView(handle, LinearLayout.LayoutParams(dp(10), dp(84)))
        }
        val p = LP(-2, -2, LP.TYPE_APPLICATION_OVERLAY, overlayFlags(), PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 0; y = dp(220)
        }

        var downY = 0f; var startY = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downY = e.rawY; startY = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dy = e.rawY - downY
                    if (!moved && Math.abs(dy) > dp(8)) moved = true
                    if (moved) {
                        val u = usableBounds(wm, this)
                        p.y = (startY + dy).toInt().coerceIn(u.top, maxOf(u.top, u.bottom - dp(100)))
                        try { wm.updateViewLayout(rootView, p) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        try {
            wm.addView(rootView, p)
            sidebar = rootView; sbParams = p; sbPanel = panel
        } catch (e: Exception) {
            toast("Could not show sidebar: ${e.message}")
        }
    }

    /** Keep the sidebar handle above windows that were just (re)added. */
    private fun bumpSidebar() {
        val v = sidebar ?: return
        val p = sbParams ?: return
        ui.post {
            if (sidebar !== v) return@post
            try { wm.removeViewImmediate(v); wm.addView(v, p) } catch (_: Exception) {}
        }
    }

    private fun togglePanel() {
        val panel = sbPanel ?: return
        if (panel.visibility == View.VISIBLE) panel.visibility = View.GONE
        else { refreshPanel(); panel.visibility = View.VISIBLE }
    }

    private fun refreshPanelIfOpen() { if (sbPanel?.visibility == View.VISIBLE) refreshPanel() }

    private fun refreshPanel() {
        val panel = sbPanel ?: return
        panel.removeAllViews()
        fun add(v: View) = panel.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        panel.addView(txt("Hyper Float", 15f, Hx.TEXT, true))
        fun tool(label: String, t: String) = add(pill(label) { openTool(t); togglePanel() })
        tool("📝  Notes", "notes"); tool("🧮  Calculator", "calc")
        tool("🌐  Browser", "web"); tool("⏱  Stopwatch", "stopwatch")
        add(pill("▦  App launcher", Hx.ACCENT, 0xFFFFFFFF.toInt()) {
            togglePanel()
            try {
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { toast("Could not open launcher") }
        })
        add(txt("Windows (${windows.size}/$MAX_WINDOWS)", 12f, Hx.SUB, true))
        if (windows.isEmpty()) add(txt("None open", 12f, Hx.SUB))
        for (w in windows.values.toList()) {
            val suffix = if (bubbles.containsKey(w.id)) "  · minimized" else ""
            add(pill(w.title + suffix, sp = 13f) { raise(w); togglePanel() })
        }
        if (windows.isNotEmpty()) add(pill("Close all", sp = 13f) { windows.values.toList().forEach { onClose(it) } })
        add(pill("Stop Hyper Float", Hx.DANGER, 0xFFFFFFFF.toInt(), 13f) { stopSelf() })
    }
}
