package com.hyperfloat.app

import android.content.Context
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.TextView

/** HyperOS-inspired palette. */
object Hx {
    val BG = 0xFFF4F5F7.toInt()
    val CARD = 0xFFFFFFFF.toInt()
    val ACCENT = 0xFF0D84FF.toInt()
    val TEXT = 0xFF1B1C1F.toInt()
    val SUB = 0xFF7B7F87.toInt()
    val SOFT = 0xFFE9EBEF.toInt()
    val DANGER = 0xFFFF4D4F.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun round(color: Int, radiusPx: Float, strokeColor: Int? = null, strokePx: Int = 0) =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx
        if (strokeColor != null) setStroke(strokePx, strokeColor)
    }

fun Context.txt(text: String, sp: Float = 14f, color: Int = Hx.TEXT, bold: Boolean = false) =
    TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

fun Context.pill(
    text: String, bg: Int = Hx.SOFT, fg: Int = Hx.TEXT, sp: Float = 14f, onClick: () -> Unit
) = TextView(this).apply {
    this.text = text
    textSize = sp
    setTextColor(fg)
    gravity = Gravity.CENTER
    setPadding(dp(14), dp(10), dp(14), dp(10))
    background = round(bg, dp(14).toFloat())
    setOnClickListener { onClick() }
}

/** Screen area not covered by status/navigation bars. */
fun usableBounds(wm: WindowManager, ctx: Context): Rect {
    val m = wm.currentWindowMetrics
    val b = m.bounds
    val ins = m.windowInsets.getInsetsIgnoringVisibility(
        WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
    )
    var top = ins.top
    if (top == 0) {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        if (id > 0) top = ctx.resources.getDimensionPixelSize(id)
    }
    return Rect(b.left + ins.left, b.top + top, b.right - ins.right, b.bottom - ins.bottom)
}
