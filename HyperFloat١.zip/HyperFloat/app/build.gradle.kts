plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hyperfloat.app"
    compileSdk = 35   // if your build tool only has SDK 34, change both 35s to 34

    defaultConfig {
        applicationId = "com.hyperfloat.app"
        minSdk = 30
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
// No third-party dependencies on purpose: smaller APK, lower RAM, faster phone builds.
